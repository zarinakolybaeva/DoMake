-- Drop the 'tasks' table
DROP TABLE IF EXISTS tasks;
