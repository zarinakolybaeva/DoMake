-- Отмена создания таблицы users
DROP TABLE users;
