ALTER TABLE tasks DROP CONSTRAINT IF EXISTS tasks_due_date_check;
