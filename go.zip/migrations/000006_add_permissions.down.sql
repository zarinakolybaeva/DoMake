DROP TABLE IF EXISTS users_permissions;
DROP TABLE IF EXISTS permissions;